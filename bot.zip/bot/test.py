from textblob import TextBlob
testimonial = TextBlob("Textblob is amazingly simple to use. What great fun!")
polarity=testimonial.sentiment.polarity
subjectivity=testimonial.sentiment.subjectivity
print(polarity)
print(subjectivity)
